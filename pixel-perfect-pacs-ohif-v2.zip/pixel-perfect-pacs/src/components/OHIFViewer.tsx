import { useEffect, useRef, useState } from 'react';
import type { Study } from '@/types';

interface OHIFViewerProps {
  study: Study;
  orthancBaseUrl: string;
}

export default function OHIFViewer({ study, orthancBaseUrl }: OHIFViewerProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [viewerUrl, setViewerUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    // Construir URL do OHIF Viewer
    // Usando OHIF Viewer hospedado publicamente
    const ohifBaseUrl = 'https://viewer.ohif.org/viewer';
    
    // Configurar DICOMweb datasource
    const datasourceConfig = {
      StudyInstanceUIDs: study.study_instance_uid,
      SeriesInstanceUIDs: '',
      SOPInstanceUIDs: '',
      sources: JSON.stringify([
        {
          namespace: '@ohif/extension-default.dataSourcesModule.dicomweb',
          sourceName: 'dicomweb',
          configuration: {
            friendlyName: study.patient_name,
            name: 'Orthanc',
            wadoUriRoot: `${orthancBaseUrl}/wado`,
            qidoRoot: `${orthancBaseUrl}/dicom-web`,
            wadoRoot: `${orthancBaseUrl}/dicom-web`,
            qidoSupportsIncludeField: false,
            imageRendering: 'wadors',
            thumbnailRendering: 'wadors',
            enableStudyLazyLoad: true,
            supportsFuzzyMatching: false,
            supportsWildcard: true,
            staticWado: true,
            singlepart: 'bulkdata,video',
            bulkDataURI: {
              enabled: true,
              relativeResolution: 'studies',
            },
          },
        },
      ]),
    };

    // Construir query params
    const params = new URLSearchParams({
      StudyInstanceUIDs: study.study_instance_uid,
      url: orthancBaseUrl,
    });

    const url = `${ohifBaseUrl}?${params.toString()}`;
    setViewerUrl(url);
    setLoading(false);
  }, [study, orthancBaseUrl]);

  const handleIframeLoad = () => {
    setLoading(false);
  };

  const handleIframeError = () => {
    setError('Erro ao carregar o visualizador DICOM');
    setLoading(false);
  };

  if (error) {
    return (
      <div className="flex-1 flex items-center justify-center bg-card rounded border border-border">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
            <svg className="h-6 w-6 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">{error}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Verifique a conexão com o servidor Orthanc
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative bg-black rounded overflow-hidden">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-card z-10">
          <div className="text-center space-y-3">
            <div className="h-8 w-8 mx-auto animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <p className="text-xs text-muted-foreground">Carregando visualizador...</p>
          </div>
        </div>
      )}
      
      <iframe
        ref={iframeRef}
        src={viewerUrl}
        className="w-full h-full border-0"
        title="OHIF DICOM Viewer"
        allow="fullscreen"
        onLoad={handleIframeLoad}
        onError={handleIframeError}
        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
      />
    </div>
  );
}
