import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getStudyById, getUnits } from '@/services/api';
import type { Study, Unit } from '@/types';
import { formatPatientName } from '@/types';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Maximize2, AlertCircle } from 'lucide-react';
import OHIFViewer from '@/components/OHIFViewer';

export default function ViewerPage() {
  const { studyId } = useParams<{ studyId: string }>();
  const [study, setStudy] = useState<Study | null>(null);
  const [unit, setUnit] = useState<Unit | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const loadData = async () => {
      if (!studyId) return;
      
      try {
        const studyData = await getStudyById(studyId);
        setStudy(studyData);

        const units = await getUnits();
        const studyUnit = units.find(u => u.id === studyData.unit_id);
        
        if (!studyUnit) {
          setError('Unidade não encontrada');
          setLoading(false);
          return;
        }

        if (!studyUnit.orthanc_base_url) {
          setError('URL do Orthanc não configurada para esta unidade');
          setLoading(false);
          return;
        }

        setUnit(studyUnit);
        setLoading(false);
      } catch (err) {
        console.error('Erro ao carregar dados:', err);
        setError('Erro ao carregar dados do estudo');
        setLoading(false);
      }
    };

    loadData();
  }, [studyId]);

  const handleFullscreen = () => {
    const elem = document.documentElement;
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center space-y-3">
          <div className="h-8 w-8 mx-auto animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <p className="text-sm text-muted-foreground">Carregando estudo...</p>
        </div>
      </div>
    );
  }

  if (error || !study || !unit) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
            <AlertCircle className="h-6 w-6 text-destructive" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">
              {error || 'Erro ao carregar estudo'}
            </p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link to="/studies">Voltar para Estudos</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
        <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
          <Link to="/studies"><ArrowLeft className="h-4 w-4" /></Link>
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-semibold text-foreground truncate">
            {formatPatientName(study.patient_name)}
          </h1>
          <p className="text-[10px] text-muted-foreground">
            {study.description} • {new Date(study.study_date).toLocaleDateString('pt-BR')} • {unit.name}
          </p>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 text-xs gap-1.5" 
          onClick={handleFullscreen}
          title="Tela cheia"
        >
          <Maximize2 className="h-3.5 w-3.5" /> Tela Cheia
        </Button>
      </div>

      <div className="flex-1 overflow-hidden p-2">
        <OHIFViewer 
          study={study} 
          orthancBaseUrl={unit.orthanc_base_url} 
        />
      </div>
    </div>
  );
}
