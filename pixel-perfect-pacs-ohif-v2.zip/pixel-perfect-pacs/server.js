import 'dotenv/config';
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Usar porta 4000 para evitar conflito com pacs-portal (porta 3000)
const PORT = 4000;

// Enable CORS
app.use(cors({
  origin: '*',
  credentials: true,
}));

// Proxy para Orthanc DICOMweb
// Exemplo: /orthanc-proxy/dicom-web/* -> http://IP_PUBLICO:8042/dicom-web/*
app.use('/orthanc-proxy', createProxyMiddleware({
  target: process.env.ORTHANC_URL || 'http://localhost:8042',
  changeOrigin: true,
  pathRewrite: {
    '^/orthanc-proxy': '',
  },
  onProxyReq: (proxyReq, req, res) => {
    // Adicionar autenticação básica se necessário
    if (process.env.ORTHANC_USER && process.env.ORTHANC_PASSWORD) {
      const auth = Buffer.from(`${process.env.ORTHANC_USER}:${process.env.ORTHANC_PASSWORD}`).toString('base64');
      proxyReq.setHeader('Authorization', `Basic ${auth}`);
    }
    
    // Log para debug
    console.log(`[Proxy] ${req.method} ${req.url} -> ${proxyReq.path}`);
  },
  onProxyRes: (proxyRes, req, res) => {
    // Adicionar headers CORS
    proxyRes.headers['Access-Control-Allow-Origin'] = '*';
    proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
    proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  },
  onError: (err, req, res) => {
    console.error('[Proxy Error]', err);
    res.status(500).json({ error: 'Erro ao conectar com Orthanc', details: err.message });
  },
}));

// Servir arquivos estáticos do build
app.use(express.static(path.join(__dirname, 'dist')));

// SPA fallback - todas as rotas retornam index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
  console.log(`📡 Proxy Orthanc: ${process.env.ORTHANC_URL || 'http://localhost:8042'}`);
});
