#!/bin/bash

# 🧪 Script de Testes de Integração - OHIF Viewer + Orthanc
# Autor: Sistema PACS
# Data: 2026-02-17

set -e  # Parar em caso de erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configurações
ORTHANC_URL="${ORTHANC_URL:-http://localhost:8042}"
PORTAL_URL="${PORTAL_URL:-http://localhost:4000}"
ORTHANC_USER="${ORTHANC_USER:-orthanc}"
ORTHANC_PASSWORD="${ORTHANC_PASSWORD:-orthanc}"

# Contadores
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_TOTAL=0

# Funções auxiliares
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
    ((TESTS_PASSED++))
    ((TESTS_TOTAL++))
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
    ((TESTS_FAILED++))
    ((TESTS_TOTAL++))
}

log_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Banner
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     🧪 Testes de Integração - OHIF Viewer + Orthanc      ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# TC-001: Verificar se Orthanc está rodando
log_info "TC-001: Verificando conectividade com Orthanc..."
if curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/system" > /dev/null; then
    log_success "TC-001: Orthanc está acessível em $ORTHANC_URL"
else
    log_error "TC-001: Falha ao conectar com Orthanc em $ORTHANC_URL"
fi

# TC-002: Verificar se DICOMweb está habilitado
log_info "TC-002: Verificando plugin DICOMweb..."
DICOMWEB_CHECK=$(curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/system" | grep -o '"DicomWeb"' || echo "")
if [ -n "$DICOMWEB_CHECK" ]; then
    log_success "TC-002: Plugin DICOMweb está habilitado"
else
    log_error "TC-002: Plugin DICOMweb NÃO está habilitado"
fi

# TC-003: Verificar endpoint QIDO-RS (Query)
log_info "TC-003: Testando endpoint QIDO-RS..."
QIDO_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/dicom-web/studies")
if [ "$QIDO_STATUS" = "200" ]; then
    log_success "TC-003: Endpoint QIDO-RS respondendo (HTTP $QIDO_STATUS)"
else
    log_error "TC-003: Endpoint QIDO-RS falhou (HTTP $QIDO_STATUS)"
fi

# TC-004: Verificar endpoint WADO-RS (Retrieve)
log_info "TC-004: Testando endpoint WADO-RS..."
WADO_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/wado")
if [ "$WADO_STATUS" = "200" ] || [ "$WADO_STATUS" = "400" ]; then
    # 400 é esperado sem parâmetros, mas significa que o endpoint existe
    log_success "TC-004: Endpoint WADO-RS respondendo (HTTP $WADO_STATUS)"
else
    log_error "TC-004: Endpoint WADO-RS falhou (HTTP $WADO_STATUS)"
fi

# TC-005: Verificar se Portal está rodando
log_info "TC-005: Verificando se Portal PACS está acessível..."
PORTAL_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$PORTAL_URL")
if [ "$PORTAL_STATUS" = "200" ]; then
    log_success "TC-005: Portal PACS está acessível em $PORTAL_URL"
else
    log_error "TC-005: Portal PACS não está acessível (HTTP $PORTAL_STATUS)"
fi

# TC-006: Verificar proxy do Portal
log_info "TC-006: Testando proxy /orthanc-proxy/..."
PROXY_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$PORTAL_URL/orthanc-proxy/system")
if [ "$PROXY_STATUS" = "200" ]; then
    log_success "TC-006: Proxy do Portal funcionando corretamente"
else
    log_error "TC-006: Proxy do Portal falhou (HTTP $PROXY_STATUS)"
fi

# TC-007: Verificar headers CORS
log_info "TC-007: Verificando headers CORS..."
CORS_HEADER=$(curl -s -I "$PORTAL_URL/orthanc-proxy/system" | grep -i "access-control-allow-origin" || echo "")
if [ -n "$CORS_HEADER" ]; then
    log_success "TC-007: Headers CORS configurados corretamente"
else
    log_warning "TC-007: Headers CORS não encontrados (pode causar problemas)"
fi

# TC-008: Verificar número de estudos no Orthanc
log_info "TC-008: Contando estudos disponíveis no Orthanc..."
STUDIES_COUNT=$(curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/studies" | grep -o '"' | wc -l)
STUDIES_COUNT=$((STUDIES_COUNT / 2))  # Dividir por 2 porque cada ID tem 2 aspas
if [ "$STUDIES_COUNT" -gt 0 ]; then
    log_success "TC-008: Orthanc contém $STUDIES_COUNT estudo(s)"
else
    log_warning "TC-008: Nenhum estudo encontrado no Orthanc (envie dados de teste)"
fi

# TC-009: Verificar latência do Orthanc
log_info "TC-009: Medindo latência do Orthanc..."
START_TIME=$(date +%s%N)
curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/system" > /dev/null
END_TIME=$(date +%s%N)
LATENCY=$(( (END_TIME - START_TIME) / 1000000 ))  # Converter para ms
if [ "$LATENCY" -lt 1000 ]; then
    log_success "TC-009: Latência do Orthanc: ${LATENCY}ms (< 1s)"
else
    log_warning "TC-009: Latência do Orthanc: ${LATENCY}ms (> 1s)"
fi

# TC-010: Verificar versão do Orthanc
log_info "TC-010: Verificando versão do Orthanc..."
ORTHANC_VERSION=$(curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/system" | grep -o '"Version" : "[^"]*"' | cut -d'"' -f4)
if [ -n "$ORTHANC_VERSION" ]; then
    log_success "TC-010: Orthanc versão $ORTHANC_VERSION detectada"
else
    log_error "TC-010: Não foi possível detectar versão do Orthanc"
fi

# TC-011: Verificar se há estudos com modalidade CT
log_info "TC-011: Buscando estudos de modalidade CT..."
CT_STUDIES=$(curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/tools/find" \
    -H "Content-Type: application/json" \
    -d '{"Level":"Study","Query":{"Modality":"CT"},"Expand":false}' | grep -o '"' | wc -l)
CT_STUDIES=$((CT_STUDIES / 2))
if [ "$CT_STUDIES" -gt 0 ]; then
    log_success "TC-011: Encontrados $CT_STUDIES estudo(s) CT"
else
    log_warning "TC-011: Nenhum estudo CT encontrado"
fi

# TC-012: Verificar se há estudos com modalidade MR
log_info "TC-012: Buscando estudos de modalidade MR..."
MR_STUDIES=$(curl -s -u "$ORTHANC_USER:$ORTHANC_PASSWORD" "$ORTHANC_URL/tools/find" \
    -H "Content-Type: application/json" \
    -d '{"Level":"Study","Query":{"Modality":"MR"},"Expand":false}' | grep -o '"' | wc -l)
MR_STUDIES=$((MR_STUDIES / 2))
if [ "$MR_STUDIES" -gt 0 ]; then
    log_success "TC-012: Encontrados $MR_STUDIES estudo(s) MR"
else
    log_warning "TC-012: Nenhum estudo MR encontrado"
fi

# TC-013: Verificar uso de memória do Orthanc
log_info "TC-013: Verificando uso de memória do Orthanc..."
ORTHANC_PID=$(pgrep -f "Orthanc" | head -1)
if [ -n "$ORTHANC_PID" ]; then
    MEMORY_MB=$(ps -p "$ORTHANC_PID" -o rss= | awk '{print int($1/1024)}')
    if [ "$MEMORY_MB" -lt 2048 ]; then
        log_success "TC-013: Uso de memória do Orthanc: ${MEMORY_MB}MB (< 2GB)"
    else
        log_warning "TC-013: Uso de memória do Orthanc: ${MEMORY_MB}MB (> 2GB)"
    fi
else
    log_warning "TC-013: Processo Orthanc não encontrado localmente"
fi

# TC-014: Verificar uso de CPU do Orthanc
log_info "TC-014: Verificando uso de CPU do Orthanc..."
if [ -n "$ORTHANC_PID" ]; then
    CPU_PERCENT=$(ps -p "$ORTHANC_PID" -o %cpu= | awk '{print int($1)}')
    if [ "$CPU_PERCENT" -lt 80 ]; then
        log_success "TC-014: Uso de CPU do Orthanc: ${CPU_PERCENT}% (< 80%)"
    else
        log_warning "TC-014: Uso de CPU do Orthanc: ${CPU_PERCENT}% (> 80%)"
    fi
else
    log_warning "TC-014: Processo Orthanc não encontrado localmente"
fi

# TC-015: Verificar espaço em disco
log_info "TC-015: Verificando espaço em disco..."
DISK_USAGE=$(df -h /var/lib/orthanc 2>/dev/null | awk 'NR==2 {print $5}' | sed 's/%//')
if [ -n "$DISK_USAGE" ]; then
    if [ "$DISK_USAGE" -lt 80 ]; then
        log_success "TC-015: Uso de disco: ${DISK_USAGE}% (< 80%)"
    else
        log_warning "TC-015: Uso de disco: ${DISK_USAGE}% (> 80%)"
    fi
else
    log_warning "TC-015: Não foi possível verificar uso de disco"
fi

# Resumo dos testes
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                    📊 Resumo dos Testes                    ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo -e "Total de testes executados: ${BLUE}$TESTS_TOTAL${NC}"
echo -e "Testes aprovados:          ${GREEN}$TESTS_PASSED${NC}"
echo -e "Testes falhados:           ${RED}$TESTS_FAILED${NC}"
echo ""

# Taxa de sucesso
if [ "$TESTS_TOTAL" -gt 0 ]; then
    SUCCESS_RATE=$(( (TESTS_PASSED * 100) / TESTS_TOTAL ))
    echo -e "Taxa de sucesso:           ${BLUE}${SUCCESS_RATE}%${NC}"
    echo ""
    
    if [ "$SUCCESS_RATE" -ge 90 ]; then
        echo -e "${GREEN}✓ Sistema aprovado para uso!${NC}"
        exit 0
    elif [ "$SUCCESS_RATE" -ge 70 ]; then
        echo -e "${YELLOW}⚠ Sistema funcional, mas com alertas${NC}"
        exit 0
    else
        echo -e "${RED}✗ Sistema com problemas críticos${NC}"
        exit 1
    fi
else
    echo -e "${RED}✗ Nenhum teste foi executado${NC}"
    exit 1
fi
