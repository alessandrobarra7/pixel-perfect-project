# 🚀 Guia Rápido de Testes - OHIF Viewer

## ⚡ Início Rápido

### 1. Executar Testes Automatizados

```bash
cd /home/ubuntu/pixel-perfect-pacs

# Executar script de testes
./test-integration.sh

# Com variáveis personalizadas
ORTHANC_URL=http://192.168.1.100:8042 \
ORTHANC_USER=admin \
ORTHANC_PASSWORD=senha123 \
./test-integration.sh
```

### 2. Testes Manuais Básicos

#### Teste 1: Verificar Orthanc
```bash
# Testar conectividade
curl http://localhost:8042/system

# Listar estudos
curl http://localhost:8042/studies

# Testar DICOMweb
curl http://localhost:8042/dicom-web/studies
```

#### Teste 2: Verificar Portal
```bash
# Testar portal
curl http://localhost:4000

# Testar proxy
curl http://localhost:4000/orthanc-proxy/system
```

#### Teste 3: Visualizar no Navegador
1. Abrir: http://localhost:4000
2. Login: `admin@example.com` (qualquer senha)
3. Ir em **Estudos**
4. Clicar em **Visualizar** (ícone de olho)
5. Aguardar OHIF Viewer carregar

---

## 📋 Checklist de Testes Rápidos

### Antes de Iniciar
- [ ] Orthanc rodando
- [ ] Portal rodando
- [ ] Pelo menos 1 estudo no Orthanc
- [ ] Navegador moderno (Chrome/Firefox)

### Testes Essenciais (5 minutos)
- [ ] TC-001: Orthanc acessível
- [ ] TC-002: DICOMweb habilitado
- [ ] TC-005: Portal acessível
- [ ] TC-006: Proxy funcionando
- [ ] Visualização manual no navegador

### Testes de Modalidade (15 minutos)
- [ ] TC-004: Visualizar CT
- [ ] TC-005: Visualizar MR
- [ ] TC-006: Visualizar CR/DX

### Testes de Performance (10 minutos)
- [ ] TC-010: Estudo grande (1000+ imagens)
- [ ] TC-012: Conexão lenta (3G)

### Testes de Erro (10 minutos)
- [ ] TC-013: Orthanc offline
- [ ] TC-015: Timeout de rede

---

## 🎯 Cenários de Teste Prioritários

### Cenário 1: Primeiro Uso (Crítico)
**Objetivo:** Validar que um novo usuário consegue visualizar um exame

**Passos:**
1. Instalar e configurar Orthanc
2. Enviar 1 estudo CT de teste
3. Configurar unidade no portal
4. Visualizar estudo no OHIF

**Tempo estimado:** 15 minutos  
**Critério de sucesso:** Imagens carregam em < 10 segundos

---

### Cenário 2: Uso Diário (Alta Prioridade)
**Objetivo:** Simular workflow típico de radiologista

**Passos:**
1. Modalidade envia 10 estudos via DICOM
2. Radiologista visualiza cada um no OHIF
3. Cria laudos para 5 estudos
4. Finaliza e gera PDFs

**Tempo estimado:** 30 minutos  
**Critério de sucesso:** Nenhum erro ou travamento

---

### Cenário 3: Stress Test (Média Prioridade)
**Objetivo:** Validar comportamento sob carga

**Passos:**
1. Enviar 100 estudos para Orthanc
2. 5 usuários simultâneos visualizando
3. Monitorar CPU e memória

**Tempo estimado:** 1 hora  
**Critério de sucesso:** CPU < 80%, Memória < 4GB

---

## 🐛 Troubleshooting Rápido

### Problema: "Orthanc não acessível"
**Solução:**
```bash
# Verificar se está rodando
sudo systemctl status orthanc

# Reiniciar
sudo systemctl restart orthanc

# Ver logs
sudo journalctl -u orthanc -f
```

### Problema: "DICOMweb não habilitado"
**Solução:**
```bash
# Editar configuração
sudo nano /etc/orthanc/orthanc.json

# Adicionar:
{
  "DicomWeb": {
    "Enable": true
  }
}

# Reiniciar
sudo systemctl restart orthanc
```

### Problema: "OHIF não carrega imagens"
**Solução:**
1. Abrir DevTools (F12)
2. Verificar erros no Console
3. Verificar requisições em Network
4. Confirmar Study UID correto
5. Testar URL do Orthanc manualmente

### Problema: "Erro de CORS"
**Solução:**
O proxy deve resolver automaticamente. Se persistir:
```bash
# Verificar logs do proxy
tail -f /home/ubuntu/pixel-perfect-pacs/server.log

# Reiniciar servidor
cd /home/ubuntu/pixel-perfect-pacs
npm run server
```

---

## 📊 Interpretando Resultados

### Script de Testes

**Taxa de Sucesso:**
- **≥ 90%**: ✅ Sistema aprovado
- **70-89%**: ⚠️ Funcional com alertas
- **< 70%**: ❌ Problemas críticos

**Testes Críticos (não podem falhar):**
- TC-001: Orthanc acessível
- TC-002: DICOMweb habilitado
- TC-005: Portal acessível
- TC-006: Proxy funcionando

---

## 📝 Registrando Bugs

Se encontrar um problema:

1. **Capturar evidências:**
   - Screenshot da tela
   - Console do navegador (F12)
   - Logs do servidor
   - Logs do Orthanc

2. **Anotar detalhes:**
   - Caso de teste (ex: TC-004)
   - Passos para reproduzir
   - Resultado esperado vs obtido
   - Ambiente (navegador, OS, versões)

3. **Reportar:**
   - Criar issue no repositório
   - Ou enviar para equipe de desenvolvimento

---

## 🎓 Datasets de Teste Recomendados

### Opção 1: TCIA (The Cancer Imaging Archive)
**URL:** https://www.cancerimagingarchive.net/

**Datasets úteis:**
- LIDC-IDRI (CT de tórax)
- TCGA-GBM (MR de crânio)
- CBIS-DDSM (Mamografia)

**Como usar:**
1. Baixar dataset
2. Enviar para Orthanc via Orthanc Explorer
3. Ou usar `storescu` (DICOM C-STORE)

### Opção 2: Orthanc Demo Server
**URL:** https://demo.orthanc-server.com/

**Credenciais:**
- Usuário: `demo`
- Senha: `demo`

**Como usar:**
1. Configurar como fonte remota no Orthanc
2. Fazer query/retrieve de estudos
3. Ou baixar manualmente e reenviar

### Opção 3: DICOM Library
**URL:** https://www.dicomlibrary.com/

**Vantagens:**
- Exemplos de todas as modalidades
- Arquivos pequenos para testes rápidos
- Gratuito e sem cadastro

---

## ⏱️ Estimativa de Tempo

| Atividade | Tempo | Prioridade |
|-----------|-------|------------|
| Testes automatizados | 5 min | Alta |
| Testes manuais básicos | 10 min | Alta |
| Testes de modalidade | 30 min | Média |
| Testes de performance | 1 hora | Média |
| Testes de segurança | 1 hora | Alta |
| Testes de usabilidade | 2 horas | Baixa |
| **Total** | **~5 horas** | - |

---

## 📞 Suporte

**Dúvidas sobre testes:**
- Consultar: `TEST-PLAN.md` (plano completo)
- Issues: GitHub repository
- Comunidade OHIF: https://community.ohif.org/

**Problemas técnicos:**
- Logs do Orthanc: `/var/log/orthanc/`
- Logs do Portal: `server.log`
- DevTools do navegador (F12)

---

**🎉 Boa sorte com os testes!**
