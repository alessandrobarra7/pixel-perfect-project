# 🚀 Guia de Deploy - Portal PACS com OHIF Viewer

## 📍 Status Atual

✅ **Servidor rodando**: https://4000-i2a7rzyj0loqgcy85051x-b3aa6d1d.us2.manus.computer  
✅ **OHIF Viewer integrado**: Pronto para conectar ao Orthanc  
✅ **Proxy DICOMweb configurado**: `/orthanc-proxy/*`  

---

## 🎯 Próximos Passos para Produção

### 1. Configurar IP Público do Orthanc

Você precisa do **IP público** e **porta** do servidor Orthanc. Exemplo:

```
IP: 203.0.113.45
Porta: 8042
URL completa: http://203.0.113.45:8042
```

### 2. Cadastrar Unidade no Sistema

1. Faça login no portal (usuário mock: `admin@example.com`)
2. Vá em **Admin → Unidades**
3. Clique em **Nova Unidade**
4. Preencha os campos:

```
Nome: Hospital Central
Slug: hospital-central
AE Title: ORTHANC
IP: 203.0.113.45
Porta: 8042
Orthanc URL: http://203.0.113.45:8042
```

5. Clique em **Salvar**

### 3. Testar Visualizador

1. Vá em **Estudos**
2. Clique no ícone de **visualizar** (olho) em qualquer estudo
3. O OHIF Viewer será carregado automaticamente
4. As imagens DICOM serão buscadas do Orthanc configurado

---

## 🔧 Configuração do Orthanc (Servidor Remoto)

### Arquivo `orthanc.json`

Certifique-se de que o Orthanc tem estas configurações:

```json
{
  "Name": "Hospital Central",
  "HttpPort": 8042,
  "RemoteAccessAllowed": true,
  "AuthenticationEnabled": true,
  "RegisteredUsers": {
    "orthanc": "orthanc"
  },
  
  "DicomWeb": {
    "Enable": true,
    "Root": "/dicom-web/",
    "EnableWado": true,
    "WadoRoot": "/wado/",
    "Ssl": false
  },
  
  "HttpsCACertificates": "",
  "SslEnabled": false,
  
  "CorsEnabled": true,
  "CorsAllowedOrigins": "*",
  "CorsAllowedMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  "CorsAllowedHeaders": ["*"]
}
```

### Reiniciar Orthanc

```bash
sudo systemctl restart orthanc
```

### Abrir Firewall

```bash
# Ubuntu/Debian
sudo ufw allow 8042/tcp
sudo ufw reload

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=8042/tcp
sudo firewall-cmd --reload
```

### Testar Conectividade

```bash
# Do seu computador local
curl http://SEU_IP:8042/system

# Deve retornar JSON com informações do Orthanc
```

---

## 🌐 Deploy em Produção

### Opção 1: VPS/Servidor Dedicado

```bash
# 1. Clonar repositório
git clone https://github.com/seu-usuario/pixel-perfect-pacs.git
cd pixel-perfect-pacs

# 2. Instalar dependências
npm install

# 3. Configurar .env
cp .env.example .env
nano .env

# Editar:
# ORTHANC_URL=http://SEU_IP_PUBLICO:8042
# ORTHANC_USER=orthanc
# ORTHANC_PASSWORD=orthanc

# 4. Build
npm run build

# 5. Instalar PM2 (gerenciador de processos)
npm install -g pm2

# 6. Iniciar servidor
pm2 start server.js --name pacs-portal

# 7. Configurar para iniciar no boot
pm2 startup
pm2 save
```

### Opção 2: Docker

```dockerfile
# Dockerfile
FROM node:22-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

EXPOSE 4000

CMD ["npm", "run", "server"]
```

```bash
# Build e run
docker build -t pacs-portal .
docker run -d -p 4000:4000 \
  -e ORTHANC_URL=http://SEU_IP:8042 \
  -e ORTHANC_USER=orthanc \
  -e ORTHANC_PASSWORD=orthanc \
  --name pacs-portal \
  pacs-portal
```

### Opção 3: Nginx Reverse Proxy

```nginx
# /etc/nginx/sites-available/pacs-portal
server {
    listen 80;
    server_name pacs.seudominio.com;

    location / {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Ativar site
sudo ln -s /etc/nginx/sites-available/pacs-portal /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Configurar SSL com Let's Encrypt
sudo certbot --nginx -d pacs.seudominio.com
```

---

## 🔐 Segurança em Produção

### 1. HTTPS Obrigatório

```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obter certificado SSL
sudo certbot --nginx -d pacs.seudominio.com
```

### 2. Firewall Restritivo

```bash
# Permitir apenas portas necessárias
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw enable
```

### 3. Autenticação Forte

- Use senhas fortes no Orthanc
- Configure autenticação JWT no portal
- Implemente 2FA se possível

### 4. VPN/Túnel SSH (Recomendado)

Para máxima segurança, **não exponha o Orthanc diretamente na internet**:

```bash
# Criar túnel SSH
ssh -L 8042:localhost:8042 usuario@servidor-orthanc

# Configurar .env
ORTHANC_URL=http://localhost:8042
```

---

## 📊 Monitoramento

### Logs do Servidor

```bash
# PM2
pm2 logs pacs-portal

# Docker
docker logs -f pacs-portal

# Arquivo direto
tail -f /home/ubuntu/pixel-perfect-pacs/server.log
```

### Logs do Orthanc

```bash
tail -f /var/log/orthanc/Orthanc.log
```

### Métricas

```bash
# Status do servidor
pm2 status

# Uso de recursos
pm2 monit
```

---

## 🧪 Testes

### 1. Testar Proxy

```bash
curl https://seu-dominio.com/orthanc-proxy/system
```

### 2. Testar DICOMweb

```bash
curl https://seu-dominio.com/orthanc-proxy/dicom-web/studies
```

### 3. Testar OHIF Viewer

1. Login no portal
2. Ir em Estudos
3. Clicar em Visualizar
4. Verificar se imagens carregam

---

## 🐛 Troubleshooting

### Erro: "URL do Orthanc não configurada"

**Solução**: Configure `orthanc_base_url` na unidade (Admin → Unidades)

### Erro: "CORS blocked"

**Solução**: Adicionar no `orthanc.json`:

```json
{
  "CorsEnabled": true,
  "CorsAllowedOrigins": "*"
}
```

### Erro: "401 Unauthorized"

**Solução**: Verificar credenciais em `.env`:

```env
ORTHANC_USER=orthanc
ORTHANC_PASSWORD=orthanc
```

### OHIF Viewer não carrega imagens

**Verificar:**

1. Orthanc está rodando: `curl http://SEU_IP:8042/system`
2. DICOMweb habilitado: `curl http://SEU_IP:8042/dicom-web/studies`
3. Firewall permite porta 8042
4. Study UID está correto no banco de dados

---

## 📞 Suporte

- **OHIF**: https://community.ohif.org/
- **Orthanc**: https://groups.google.com/g/orthanc-users
- **DICOMweb**: https://www.dicomstandard.org/using/dicomweb

---

## ✅ Checklist de Deploy

- [ ] Orthanc configurado com DICOMweb
- [ ] Firewall aberto (porta 8042)
- [ ] IP público do Orthanc obtido
- [ ] Unidade cadastrada no portal
- [ ] Servidor do portal rodando
- [ ] HTTPS configurado (produção)
- [ ] Backup do banco de dados configurado
- [ ] Monitoramento ativo
- [ ] Logs sendo coletados
- [ ] Testes de visualização realizados

---

**🎉 Pronto! Seu portal PACS com OHIF Viewer está configurado e pronto para uso!**
