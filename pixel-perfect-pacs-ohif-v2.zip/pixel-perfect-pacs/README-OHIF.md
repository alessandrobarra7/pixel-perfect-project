# Integração OHIF Viewer - Portal PACS

## 📋 Visão Geral

Este projeto integra o **OHIF Viewer v3** para visualização de exames DICOM diretamente do Orthanc via IP público.

## 🏗️ Arquitetura

```
┌─────────────┐      ┌──────────────┐      ┌─────────────┐      ┌──────────────┐
│   Browser   │ ───▶ │  React App   │ ───▶ │   Proxy     │ ───▶ │   Orthanc    │
│  (Cliente)  │      │  (Frontend)  │      │  (Backend)  │      │ (IP Público) │
└─────────────┘      └──────────────┘      └─────────────┘      └──────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │ OHIF Viewer  │
                    │  (iframe)    │
                    └──────────────┘
```

## 🚀 Configuração

### 1. Variáveis de Ambiente

Copie o arquivo `.env.example` para `.env` e configure:

```bash
cp .env.example .env
```

Edite o arquivo `.env`:

```env
# IP público do seu servidor Orthanc
ORTHANC_URL=http://SEU_IP_PUBLICO:8042

# Credenciais do Orthanc (se configurado)
ORTHANC_USER=orthanc
ORTHANC_PASSWORD=orthanc

# Porta do servidor (padrão: 3000)
PORT=3000
```

### 2. Instalação

```bash
npm install
```

### 3. Desenvolvimento

```bash
npm run dev
```

O frontend estará disponível em `http://localhost:5173`

### 4. Produção

```bash
# Build do frontend
npm run build

# Iniciar servidor com proxy
npm run server
```

O servidor completo estará em `http://localhost:3000`

## 📦 Componentes

### OHIFViewer.tsx

Componente React que encapsula o OHIF Viewer via iframe.

**Props:**
- `study`: Objeto Study com dados do exame
- `orthancBaseUrl`: URL base do Orthanc (configurada na unidade)

**Exemplo de uso:**

```tsx
<OHIFViewer 
  study={studyData} 
  orthancBaseUrl="http://192.168.1.100:8042" 
/>
```

### Proxy Backend (server.js)

Servidor Express que:
- Serve os arquivos estáticos do build
- Cria proxy para o Orthanc (`/orthanc-proxy/*`)
- Adiciona headers CORS
- Injeta autenticação básica automaticamente

**Endpoints:**

- `GET /orthanc-proxy/dicom-web/studies` → Proxy para `ORTHANC_URL/dicom-web/studies`
- `GET /orthanc-proxy/wado/*` → Proxy para `ORTHANC_URL/wado/*`

## 🔧 Configuração do Orthanc

### orthanc.json

Certifique-se de que o Orthanc está configurado para DICOMweb:

```json
{
  "DicomWeb": {
    "Enable": true,
    "Root": "/dicom-web/",
    "EnableWado": true,
    "WadoRoot": "/wado/",
    "Ssl": false
  },
  "RemoteAccessAllowed": true,
  "AuthenticationEnabled": true,
  "RegisteredUsers": {
    "orthanc": "orthanc"
  },
  "HttpsCACertificates": "",
  "SslEnabled": false,
  "HttpPort": 8042
}
```

### Firewall

Abra a porta 8042 no firewall do servidor Orthanc:

```bash
# Ubuntu/Debian
sudo ufw allow 8042/tcp

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=8042/tcp
sudo firewall-cmd --reload
```

## 🔐 Segurança

⚠️ **IMPORTANTE**: Em produção, sempre use:

1. **HTTPS** para o servidor web
2. **Autenticação** no Orthanc
3. **Firewall** restringindo acesso ao Orthanc
4. **VPN** ou **túnel SSH** para acesso remoto seguro

## 📊 Fluxo de Visualização

1. Usuário clica em "Visualizar" em um estudo
2. Sistema carrega dados do estudo e da unidade
3. Verifica se a unidade tem `orthanc_base_url` configurada
4. Componente `OHIFViewer` monta iframe com URL do OHIF público
5. OHIF Viewer carrega e faz requisições DICOMweb para o Orthanc
6. Proxy backend redireciona requisições adicionando autenticação
7. Imagens DICOM são exibidas no visualizador

## 🧪 Testes

### Testar Conexão Orthanc

```bash
# Verificar se Orthanc está acessível
curl http://SEU_IP:8042/system

# Testar DICOMweb
curl http://SEU_IP:8042/dicom-web/studies
```

### Testar Proxy

```bash
# Com servidor rodando
curl http://localhost:3000/orthanc-proxy/system
```

## 🐛 Troubleshooting

### Erro: "URL do Orthanc não configurada"

**Solução**: Vá em Admin → Unidades e configure o campo "Orthanc URL" para a unidade.

### Erro: "Erro ao conectar com Orthanc"

**Causas possíveis:**
1. Orthanc não está rodando
2. IP/porta incorretos
3. Firewall bloqueando conexão
4. Credenciais incorretas

**Verificar:**

```bash
# Ping no servidor
ping SEU_IP

# Testar porta
telnet SEU_IP 8042

# Verificar logs do Orthanc
tail -f /var/log/orthanc/Orthanc.log
```

### OHIF Viewer não carrega imagens

**Soluções:**

1. Verificar console do browser (F12) para erros CORS
2. Confirmar que DICOMweb está habilitado no Orthanc
3. Testar URL diretamente: `http://SEU_IP:8042/dicom-web/studies`
4. Verificar se Study UID está correto

## 📚 Referências

- [OHIF Viewer Documentation](https://docs.ohif.org/)
- [Orthanc DICOMweb Plugin](https://book.orthanc-server.com/plugins/dicomweb.html)
- [DICOMweb Standard](https://www.dicomstandard.org/using/dicomweb)

## 🆘 Suporte

Para problemas ou dúvidas, consulte:
- [OHIF Community Forum](https://community.ohif.org/)
- [Orthanc Users Group](https://groups.google.com/g/orthanc-users)
