# 🧪 Plano de Testes - Integração OHIF Viewer + Orthanc

## 📋 Visão Geral

Este documento descreve o plano completo de testes para validar a integração do OHIF Viewer v3 com o Orthanc em diferentes cenários, configurações e modalidades DICOM.

**Objetivo**: Garantir que o portal PACS consiga visualizar exames DICOM de forma confiável, segura e performática em ambientes de produção.

---

## 🎯 Escopo dos Testes

### Funcionalidades Testadas
- ✅ Conexão com Orthanc via DICOMweb
- ✅ Autenticação básica do Orthanc
- ✅ Proxy backend funcionando corretamente
- ✅ Carregamento de estudos DICOM
- ✅ Visualização de imagens em diferentes modalidades
- ✅ Ferramentas de manipulação de imagem (zoom, pan, window/level)
- ✅ Navegação entre séries e instâncias
- ✅ Performance com grandes volumes de dados
- ✅ Tratamento de erros e timeouts
- ✅ Compatibilidade com diferentes versões do Orthanc

### Fora do Escopo
- ❌ Testes de segurança avançados (penetration testing)
- ❌ Testes de carga extrema (>1000 usuários simultâneos)
- ❌ Validação clínica de diagnósticos

---

## 🏗️ Ambiente de Testes

### Configuração Mínima

**Servidor Orthanc:**
- Versão: 1.12.0 ou superior
- Plugins: DICOMweb, GDCM
- Memória: 4GB RAM
- Armazenamento: 100GB SSD
- Sistema Operacional: Ubuntu 22.04 LTS

**Portal PACS:**
- Node.js: 22.x
- Navegadores: Chrome 120+, Firefox 120+, Safari 17+
- Conexão: Mínimo 10 Mbps

### Dados de Teste

**Modalidades DICOM:**
- CT (Tomografia Computadorizada)
- MR (Ressonância Magnética)
- CR/DX (Radiografia Digital)
- US (Ultrassom)
- MG (Mamografia)
- PT (PET/CT)

**Volumes de Dados:**
- Pequeno: 1-10 imagens (CR/DX)
- Médio: 50-200 imagens (CT simples)
- Grande: 500-1000 imagens (CT com contraste)
- Muito Grande: 2000+ imagens (PET/CT completo)

**Datasets Públicos:**
- [TCIA (The Cancer Imaging Archive)](https://www.cancerimagingarchive.net/)
- [Orthanc Demo Server](https://demo.orthanc-server.com/)
- [DICOM Library](https://www.dicomlibrary.com/)

---

## 📝 Casos de Teste

### 1. Testes de Conectividade

#### TC-001: Conexão Básica com Orthanc
**Pré-requisitos:**
- Orthanc rodando em `http://localhost:8042`
- DICOMweb habilitado

**Passos:**
1. Iniciar servidor do portal: `npm run server`
2. Abrir navegador em `http://localhost:4000`
3. Fazer login no sistema
4. Acessar Admin → Unidades
5. Cadastrar unidade com URL `http://localhost:8042`
6. Verificar mensagem de sucesso

**Resultado Esperado:**
- ✅ Unidade cadastrada sem erros
- ✅ Conexão validada automaticamente

**Critérios de Aceitação:**
- Sistema não exibe erros de rede
- Timeout máximo: 5 segundos

---

#### TC-002: Conexão com Autenticação
**Pré-requisitos:**
- Orthanc com autenticação habilitada
- Usuário: `orthanc`, Senha: `orthanc`

**Passos:**
1. Configurar `.env`:
   ```
   ORTHANC_USER=orthanc
   ORTHANC_PASSWORD=orthanc
   ```
2. Reiniciar servidor
3. Cadastrar unidade
4. Tentar acessar estudos

**Resultado Esperado:**
- ✅ Proxy injeta credenciais automaticamente
- ✅ Requisições DICOMweb retornam 200 OK

**Critérios de Aceitação:**
- Nenhum erro 401 Unauthorized
- Headers `Authorization: Basic` presentes

---

#### TC-003: Conexão com IP Público
**Pré-requisitos:**
- Orthanc acessível via IP público
- Firewall liberado (porta 8042)

**Passos:**
1. Obter IP público: `curl ifconfig.me`
2. Cadastrar unidade com `http://IP_PUBLICO:8042`
3. Testar acesso externo: `curl http://IP_PUBLICO:8042/system`
4. Visualizar estudo no portal

**Resultado Esperado:**
- ✅ Conexão estabelecida via internet
- ✅ Imagens carregam corretamente

**Critérios de Aceitação:**
- Latência < 3 segundos para primeira imagem
- Sem erros de CORS

---

### 2. Testes de Visualização por Modalidade

#### TC-004: Visualização de CT (Tomografia)
**Dataset:** CT de tórax com 150 slices

**Passos:**
1. Enviar estudo CT para Orthanc via DICOM C-STORE
2. Acessar Estudos no portal
3. Clicar em Visualizar no estudo CT
4. Aguardar carregamento do OHIF Viewer

**Validações:**
- ✅ Todas as 150 imagens carregam
- ✅ Scroll entre slices funciona suavemente
- ✅ Window/Level ajusta contraste corretamente
- ✅ Zoom e Pan respondem sem lag
- ✅ Medições (régua, ângulo) funcionam
- ✅ MPR (reconstrução multiplanar) disponível

**Critérios de Aceitação:**
- Tempo de carregamento inicial: < 10 segundos
- FPS durante scroll: > 30 fps
- Precisão de medições: ±1mm

---

#### TC-005: Visualização de MR (Ressonância)
**Dataset:** MR de crânio com múltiplas sequências (T1, T2, FLAIR)

**Passos:**
1. Enviar estudo MR multisequência
2. Visualizar no OHIF
3. Alternar entre séries (T1 → T2 → FLAIR)

**Validações:**
- ✅ Todas as séries listadas corretamente
- ✅ Troca de série instantânea (< 1s)
- ✅ Orientação anatômica correta (Axial/Sagital/Coronal)
- ✅ Informações DICOM exibidas (TR, TE, Flip Angle)

**Critérios de Aceitação:**
- Nenhuma série faltando
- Metadados DICOM precisos

---

#### TC-006: Visualização de CR/DX (Radiografia)
**Dataset:** Raio-X de tórax PA e perfil

**Passos:**
1. Enviar 2 imagens CR (PA + Perfil)
2. Visualizar no OHIF
3. Aplicar inversão de contraste
4. Usar ferramenta de anotação

**Validações:**
- ✅ Imagens carregam em alta resolução
- ✅ Inversão de contraste funciona
- ✅ Anotações (setas, textos) persistem
- ✅ Comparação lado a lado (PA vs Perfil)

**Critérios de Aceitação:**
- Resolução mantida (sem downsampling)
- Anotações salvas no estado da sessão

---

#### TC-007: Visualização de US (Ultrassom)
**Dataset:** US obstétrico com cine loops

**Passos:**
1. Enviar estudo US com vídeo
2. Visualizar no OHIF
3. Reproduzir cine loop

**Validações:**
- ✅ Vídeo reproduz suavemente
- ✅ Controles de play/pause funcionam
- ✅ Frame rate correto (conforme DICOM)
- ✅ Medições em frames específicos

**Critérios de Aceitação:**
- Reprodução sem travamentos
- FPS conforme metadados DICOM

---

#### TC-008: Visualização de MG (Mamografia)
**Dataset:** Mamografia bilateral (4 incidências)

**Passos:**
1. Enviar mamografia completa
2. Visualizar no OHIF
3. Usar hanging protocols (layout 2x2)

**Validações:**
- ✅ 4 imagens dispostas corretamente (RCC, RMLO, LCC, LMLO)
- ✅ Alta resolução mantida (importante para microcalcificações)
- ✅ Zoom até 400% sem perda de qualidade
- ✅ Ferramentas de medição precisas

**Critérios de Aceitação:**
- Resolução nativa preservada
- Layout automático por protocolo

---

#### TC-009: Visualização de PT/CT (PET/CT Fusion)
**Dataset:** PET/CT oncológico com fusão

**Passos:**
1. Enviar estudo PET/CT
2. Visualizar no OHIF
3. Ativar modo de fusão (overlay)

**Validações:**
- ✅ CT e PET carregam separadamente
- ✅ Fusão sobrepõe corretamente
- ✅ Escala de cores SUV funciona
- ✅ Sincronização entre viewports

**Critérios de Aceitação:**
- Alinhamento espacial perfeito
- SUV values corretos

---

### 3. Testes de Performance

#### TC-010: Carregamento de Estudo Grande (1000+ imagens)
**Dataset:** CT de corpo inteiro com contraste (1200 slices)

**Passos:**
1. Enviar estudo grande para Orthanc
2. Visualizar no OHIF
3. Medir tempo de carregamento

**Métricas:**
- Tempo até primeira imagem: < 5s
- Tempo até todas imagens carregadas: < 30s
- Uso de memória: < 2GB
- Scroll fluido: > 30 fps

**Critérios de Aceitação:**
- Nenhum travamento do navegador
- Progressivo loading visível

---

#### TC-011: Múltiplos Usuários Simultâneos
**Cenário:** 10 usuários visualizando estudos diferentes

**Passos:**
1. Simular 10 sessões simultâneas
2. Cada usuário abre um estudo diferente
3. Monitorar CPU e memória do servidor

**Métricas:**
- CPU do servidor: < 80%
- Memória do servidor: < 4GB
- Latência média: < 2s
- Taxa de erro: 0%

**Critérios de Aceitação:**
- Servidor não trava
- Todos os usuários visualizam normalmente

---

#### TC-012: Teste de Latência de Rede
**Cenário:** Simular conexões lentas (3G, 4G, Wi-Fi)

**Passos:**
1. Usar Chrome DevTools → Network Throttling
2. Configurar "Slow 3G" (400 Kbps)
3. Visualizar estudo CT médio (100 imagens)

**Validações:**
- ✅ Progressive loading funciona
- ✅ Primeiras imagens carregam rapidamente
- ✅ Indicador de progresso visível
- ✅ Timeout não ocorre

**Critérios de Aceitação:**
- Primeira imagem em < 10s (3G)
- Experiência degradada mas funcional

---

### 4. Testes de Erro e Recuperação

#### TC-013: Orthanc Offline
**Cenário:** Orthanc para durante visualização

**Passos:**
1. Iniciar visualização de estudo
2. Parar serviço Orthanc: `sudo systemctl stop orthanc`
3. Tentar navegar entre imagens

**Resultado Esperado:**
- ✅ Mensagem de erro clara: "Servidor DICOM indisponível"
- ✅ Imagens já carregadas permanecem visíveis
- ✅ Botão "Tentar Novamente" disponível

**Critérios de Aceitação:**
- Sem crash do navegador
- Mensagem amigável ao usuário

---

#### TC-014: Estudo Corrompido
**Cenário:** Arquivo DICOM com metadados inválidos

**Passos:**
1. Enviar arquivo DICOM corrompido para Orthanc
2. Tentar visualizar no portal

**Resultado Esperado:**
- ✅ Erro detectado antes de carregar OHIF
- ✅ Mensagem: "Estudo não pode ser visualizado"
- ✅ Log de erro detalhado no backend

**Critérios de Aceitação:**
- Sistema não trava
- Erro registrado em auditoria

---

#### TC-015: Timeout de Rede
**Cenário:** Requisição DICOMweb demora > 30s

**Passos:**
1. Simular latência extrema no proxy
2. Tentar carregar estudo

**Resultado Esperado:**
- ✅ Timeout após 30 segundos
- ✅ Mensagem: "Tempo limite excedido"
- ✅ Opção de recarregar

**Critérios de Aceitação:**
- Timeout configurável
- Retry automático opcional

---

#### TC-016: CORS Bloqueado
**Cenário:** Orthanc sem headers CORS

**Passos:**
1. Desabilitar CORS no `orthanc.json`
2. Tentar visualizar estudo

**Resultado Esperado:**
- ✅ Proxy contorna problema de CORS
- ✅ Imagens carregam normalmente

**Critérios de Aceitação:**
- Proxy injeta headers CORS
- Nenhum erro no console

---

### 5. Testes de Segurança

#### TC-017: Autenticação Inválida
**Cenário:** Credenciais erradas no `.env`

**Passos:**
1. Configurar senha incorreta
2. Tentar visualizar estudo

**Resultado Esperado:**
- ✅ Erro 401 capturado
- ✅ Mensagem: "Credenciais inválidas"
- ✅ Não expõe senha no frontend

**Critérios de Aceitação:**
- Credenciais nunca no código cliente
- Log de tentativa de acesso

---

#### TC-018: SQL Injection no Study UID
**Cenário:** Tentar injetar SQL via URL

**Passos:**
1. Acessar: `/viewer/1' OR '1'='1`
2. Verificar resposta do backend

**Resultado Esperado:**
- ✅ Input sanitizado
- ✅ Erro 400 Bad Request
- ✅ Tentativa registrada em auditoria

**Critérios de Aceitação:**
- Nenhuma query SQL executada
- Validação de entrada rigorosa

---

#### TC-019: XSS no Patient Name
**Cenário:** Patient Name com script malicioso

**Passos:**
1. Enviar DICOM com: `Patient Name: <script>alert('XSS')</script>`
2. Visualizar estudo

**Resultado Esperado:**
- ✅ Script não executado
- ✅ Nome escapado corretamente
- ✅ Exibido como texto puro

**Critérios de Aceitação:**
- Nenhum script executado
- Sanitização automática

---

### 6. Testes de Compatibilidade

#### TC-020: Diferentes Versões do Orthanc
**Versões Testadas:**
- Orthanc 1.9.7 (LTS)
- Orthanc 1.11.0
- Orthanc 1.12.0 (latest)

**Validações:**
- ✅ DICOMweb funciona em todas
- ✅ Endpoints compatíveis
- ✅ Nenhuma quebra de API

---

#### TC-021: Navegadores Diferentes
**Navegadores Testados:**
- Chrome 120+ (Windows, macOS, Linux)
- Firefox 120+
- Safari 17+ (macOS, iOS)
- Edge 120+

**Validações:**
- ✅ OHIF carrega em todos
- ✅ Ferramentas funcionam
- ✅ Performance similar

---

#### TC-022: Dispositivos Móveis
**Dispositivos:**
- iPhone 14 (iOS 17)
- Samsung Galaxy S23 (Android 14)
- iPad Pro (iPadOS 17)

**Validações:**
- ✅ Interface responsiva
- ✅ Touch gestures funcionam
- ✅ Zoom/Pan com dedos

---

### 7. Testes de Integração

#### TC-023: Fluxo Completo End-to-End
**Cenário:** Workflow completo de laudo

**Passos:**
1. Modalidade envia exame via DICOM C-STORE para Orthanc
2. Orthanc recebe e indexa
3. Portal sincroniza lista de estudos
4. Radiologista visualiza no OHIF
5. Cria laudo vinculado ao estudo
6. Finaliza e gera PDF

**Validações:**
- ✅ Exame aparece na lista em < 30s
- ✅ Visualização sem erros
- ✅ Laudo vinculado corretamente
- ✅ PDF contém Study UID

**Critérios de Aceitação:**
- Workflow sem intervenção manual
- Auditoria completa registrada

---

#### TC-024: Sincronização de Estudos
**Cenário:** Orthanc recebe novos estudos

**Passos:**
1. Portal aberto na lista de estudos
2. Enviar novo estudo para Orthanc
3. Aguardar sincronização

**Validações:**
- ✅ Novo estudo aparece automaticamente
- ✅ Polling a cada 30 segundos
- ✅ Notificação visual de novo estudo

**Critérios de Aceitação:**
- Latência máxima: 30 segundos
- Sem necessidade de refresh manual

---

### 8. Testes de Usabilidade

#### TC-025: Tempo de Aprendizado
**Cenário:** Novo usuário sem treinamento

**Passos:**
1. Usuário nunca usou OHIF
2. Tarefa: Visualizar estudo e medir lesão
3. Cronometrar tempo até conclusão

**Métricas:**
- Tempo médio: < 5 minutos
- Taxa de sucesso: > 90%
- Satisfação: > 4/5

---

#### TC-026: Acessibilidade (WCAG 2.1)
**Validações:**
- ✅ Contraste mínimo 4.5:1
- ✅ Navegação por teclado
- ✅ Screen reader compatível
- ✅ Textos alternativos em ícones

---

## 📊 Matriz de Rastreabilidade

| Requisito | Casos de Teste | Prioridade | Status |
|-----------|----------------|------------|--------|
| Conexão DICOMweb | TC-001, TC-002, TC-003 | Alta | ⏳ Pendente |
| Visualização CT | TC-004 | Alta | ⏳ Pendente |
| Visualização MR | TC-005 | Alta | ⏳ Pendente |
| Visualização CR/DX | TC-006 | Média | ⏳ Pendente |
| Visualização US | TC-007 | Média | ⏳ Pendente |
| Visualização MG | TC-008 | Média | ⏳ Pendente |
| Visualização PET/CT | TC-009 | Baixa | ⏳ Pendente |
| Performance | TC-010, TC-011, TC-012 | Alta | ⏳ Pendente |
| Tratamento de Erros | TC-013, TC-014, TC-015, TC-016 | Alta | ⏳ Pendente |
| Segurança | TC-017, TC-018, TC-019 | Crítica | ⏳ Pendente |
| Compatibilidade | TC-020, TC-021, TC-022 | Média | ⏳ Pendente |
| Integração | TC-023, TC-024 | Alta | ⏳ Pendente |
| Usabilidade | TC-025, TC-026 | Baixa | ⏳ Pendente |

---

## 🔄 Processo de Execução

### Fase 1: Testes Unitários (Semana 1)
- TC-001 a TC-003 (Conectividade)
- TC-013 a TC-016 (Erros)

### Fase 2: Testes de Modalidade (Semana 2)
- TC-004 a TC-009 (Todas as modalidades)

### Fase 3: Testes de Performance (Semana 3)
- TC-010 a TC-012 (Carga e latência)

### Fase 4: Testes de Segurança (Semana 4)
- TC-017 a TC-019 (Autenticação e injeções)

### Fase 5: Testes de Integração (Semana 5)
- TC-023 a TC-024 (End-to-end)

### Fase 6: Testes de Compatibilidade (Semana 6)
- TC-020 a TC-022 (Navegadores e dispositivos)

### Fase 7: Testes de Usabilidade (Semana 7)
- TC-025 a TC-026 (UX e acessibilidade)

---

## 📈 Métricas de Sucesso

### Critérios de Aprovação
- ✅ 100% dos testes de prioridade **Crítica** passando
- ✅ ≥ 95% dos testes de prioridade **Alta** passando
- ✅ ≥ 90% dos testes de prioridade **Média** passando
- ✅ ≥ 80% dos testes de prioridade **Baixa** passando

### KPIs de Performance
- Tempo de carregamento inicial: < 5s
- FPS durante scroll: > 30 fps
- Uso de memória: < 2GB
- Taxa de erro: < 1%
- Disponibilidade: > 99.5%

---

## 🛠️ Ferramentas de Teste

### Testes Manuais
- Navegadores: Chrome DevTools, Firefox Developer Tools
- Simulação de rede: Chrome Network Throttling
- Dispositivos móveis: BrowserStack, Sauce Labs

### Testes Automatizados
- Framework: Playwright / Cypress
- CI/CD: GitHub Actions
- Monitoramento: Sentry, LogRocket

### Testes de Carga
- Ferramenta: Apache JMeter, k6
- Cenário: 50 usuários simultâneos por 10 minutos

---

## 📝 Template de Relatório de Bug

```markdown
**ID:** BUG-XXX
**Título:** [Descrição curta do problema]
**Caso de Teste:** TC-XXX
**Severidade:** Crítica / Alta / Média / Baixa
**Prioridade:** P0 / P1 / P2 / P3

**Ambiente:**
- Navegador: Chrome 120.0.6099.109
- OS: Ubuntu 22.04
- Orthanc: 1.12.0
- Portal: v1.0.0

**Passos para Reproduzir:**
1. [Passo 1]
2. [Passo 2]
3. [Passo 3]

**Resultado Esperado:**
[O que deveria acontecer]

**Resultado Obtido:**
[O que realmente aconteceu]

**Evidências:**
- Screenshot: [anexar]
- Logs: [anexar]
- Vídeo: [link]

**Impacto:**
[Descrição do impacto no usuário]

**Sugestão de Correção:**
[Se aplicável]
```

---

## ✅ Checklist de Homologação

Antes de aprovar para produção, verificar:

- [ ] Todos os testes críticos passaram
- [ ] Performance dentro dos SLAs
- [ ] Segurança validada
- [ ] Documentação atualizada
- [ ] Treinamento da equipe realizado
- [ ] Backup e rollback testados
- [ ] Monitoramento configurado
- [ ] Logs centralizados
- [ ] Alertas configurados
- [ ] Aprovação do responsável técnico
- [ ] Aprovação do responsável clínico (se aplicável)

---

## 📞 Contatos

**Equipe de Testes:**
- QA Lead: [nome@email.com]
- Desenvolvedor: [nome@email.com]
- DevOps: [nome@email.com]

**Escalação:**
- P0/P1: Notificar imediatamente via Slack
- P2/P3: Registrar no Jira

---

**Última Atualização:** 2026-02-17  
**Versão do Documento:** 1.0  
**Próxima Revisão:** 2026-03-17
